package com.example.wearVilige;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WearViligeApplicationTests {

	@Test
	void contextLoads() {
	}

}

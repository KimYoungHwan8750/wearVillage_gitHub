package com.example.wearVilige.Controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Member;

@Controller
public class testController {
    @RequestMapping(value = "/")
    public String home() {
        return "login";
    }


    @RequestMapping(value = "/name", method = RequestMethod.GET)
    public String data_to_createUser(@RequestParam(required = false, value = "nickname") String nickname, @RequestParam(required = false, value = "email") String email, @RequestParam(required = false, value = "profile_img") String profile_img, Model model) {
        System.out.println(nickname);

        if (nickname == null && email == null) {
        } else {
            model.addAttribute("user_nickname", nickname);
            model.addAttribute("user_email", email);
            model.addAttribute("email_disabled", "disabled");
        }

        if (model.getAttribute("email_disabled") == "disabled") {
            model.addAttribute("testStyle", "background-color: #B2B2B2;");
        } else {
            model.addAttribute("testStyle", "border-bottom: solid 2px gray;");
        }
        if (profile_img != null) {
            model.addAttribute("profile_img", profile_img);
        } else {
            model.addAttribute("profile_img", "img/index/기본프사.jpg");
        }
        return "createUser.html";
    }

    @GetMapping(value = "/createUser")
    public void createUser_to_oracle(@RequestParam(required = false, value = "userNickname") String userNickname, @RequestParam(required = false, value = "userEmail") String email) {
        if (userNickname == "") {
            System.out.println("유저 닉네임을 입력해야함!");
        } else {
            System.out.println(userNickname);
        }


    }

    @PostMapping(value = "/main")
    public String finished_create_user(@RequestParam(required = false, value = "nickname") String nickname, @RequestParam(required = false, value = "email") String email, @RequestParam(required = false, value = "profile_img") String profile_img, Model model) {

        return "main";
    }

        @RequestMapping(value = "/naver", method = RequestMethod.GET)
        public String naverLogin () {
            return "createUser.html";
        }
    }
